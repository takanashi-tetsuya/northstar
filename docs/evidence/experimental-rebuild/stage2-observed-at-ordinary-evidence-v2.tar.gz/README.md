# Observed-at boxed source checks and retained failure

Base: 87ec1c238adc87f9e8342c8f7803a67aab271744.
The final ordinary record covers formatting and normal/test-target cargo check
and clippy -D warnings after boxing only the retained Effect. Test bodies did
not execute. Unchanged Python/JSON hashes reuse the initial syntax records.

The earlier large_enum_variant failure is retained under historical/. Its
code patch and the initial successful compile/syntax records are preserved in
the separate stage2-observed-at-ordinary-evidence-v1.tar.gz archive. The
historical documentation.patch reconstructs the tracked documentation bytes
present during both lint attempts and the final compilation. Combine it with
the appropriate code source.patch and base commit to reconstruct each full
tracked-file hash map. Paths in historical records describe their original
validation workspace; hashes and archived bytes are the evidence identity.

No tests, project Python imports, oracle, runner, corpus, replay, shrinker, SQL,
services or faults ran. Stage2, dedicated regressions and real adapters remain
unqualified. Never execute archived drivers without task authorization.
