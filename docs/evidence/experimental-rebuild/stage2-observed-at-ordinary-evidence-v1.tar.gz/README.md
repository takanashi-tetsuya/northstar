# Observed-at ordinary source checks

Base: 87ec1c238adc87f9e8342c8f7803a67aab271744.
This archive preserves the exact frozen source patch, 1,670-file before/after
hash maps, check driver, command logs/results, and preceding Rust formatting
record. Commands perform formatting checks, Python AST/strict JSON parsing,
and default-feature normal/test-target compilation only.

No project Python modules, tests, oracle, runner, corpus, replay, shrinker, SQL,
services, or fault scenarios were executed. Compiling regression source is not
executing it. Stage 2 and real adapter qualification remain open.

The driver is historical evidence and a reproducible description of the check
commands. Do not run it without the appropriate task execution authorization.
