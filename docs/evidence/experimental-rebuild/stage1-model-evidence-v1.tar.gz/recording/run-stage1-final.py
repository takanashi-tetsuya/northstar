#!/usr/bin/env python3
"""Record ordinary Stage 1 checks with an external stable-source envelope."""
import datetime
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/6c1169b97236/northstar-repair')
OUTPUT = Path('/workspace/scratch/6c1169b97236/stage1-contract-evidence-20261003-final')
SCOPED = (
    'scripts/lib/experiment_contract.py', 'scripts/test-experiment-contract.py',
    'scripts/mixed-traffic-soak.py', 'scripts/check-runtime-experiments.mjs',
    'scripts/test-runtime-experiments.mjs', 'catalog/runtime-experiments.json',
    'catalog/runtime-experiments.schema.json', '.github/workflows/ci.yml',
    'src/db/message_admission_repository.rs', 'crates/northstar-abuse-policy/src/model.rs',
)

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def source_map():
    return {name: sha((ROOT / name).read_bytes()) for name in SCOPED}

def digest_map(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode())

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

if OUTPUT.exists():
    raise SystemExit('refusing to overwrite a prior final evidence directory')

before = source_map()
started = now()
head_before = git('rev-parse', 'HEAD')
tree_before = git('rev-parse', 'HEAD^{tree}')
commands = [
    ('ordinary-command.log', [sys.executable, '-B', 'scripts/test-experiment-contract.py', '--evidence-dir', str(OUTPUT)]),
    ('catalog-validator.log', ['node', 'scripts/check-runtime-experiments.mjs']),
    ('catalog-tests.log', ['node', '--test', 'scripts/test-runtime-experiments.mjs']),
    ('saved-replay.log', [sys.executable, '-B', 'scripts/test-experiment-contract.py', '--replay-corpus', str(OUTPUT / 'synthetic-cases.json')]),
    ('muc-pure-tests.log', [sys.executable, '-B', 'scripts/test-integration-muc-matching.py']),
    ('documentation-check.log', ['node', 'scripts/check-documentation-consistency.mjs']),
    ('sensitive-files-check.log', ['node', 'scripts/check-tracked-sensitive-files.mjs', '--include-untracked']),
    ('diff-check.log', ['git', 'diff', '--check']),
]
records = []
for log, command in commands:
    start = now()
    monotonic = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    OUTPUT.mkdir(exist_ok=True)
    (OUTPUT / log).write_text(result.stdout)
    records.append({'argv': command, 'cwd': str(ROOT), 'started_at': start,
                    'completed_at': now(), 'elapsed_seconds': round(time.monotonic() - monotonic, 3),
                    'exit_code': result.returncode, 'log': log})
    print(json.dumps({'log': log, 'exit_code': result.returncode}), flush=True)
after = source_map()
ordinary = json.loads((OUTPUT / 'ordinary-result.json').read_text())
stable = before == after == ordinary['provenance']['files']
source_digest_matches = digest_map(before) == ordinary['provenance']['source_sha256']
head_after = git('rev-parse', 'HEAD')
envelope = {
    'schema': 'northstar-stage1-ordinary-source-envelope-v1',
    'scope': 'Pure model, fake fixture entry points and static checks only',
    'started_at': started, 'completed_at': now(),
    'actual_head_before': head_before, 'actual_head_after': head_after,
    'actual_head_tree': tree_before,
    'declared_reconstruction_anchor': ordinary['provenance']['base_commit'],
    'source_before': before, 'source_after': after,
    'source_sha256': digest_map(before), 'source_stable': stable,
    'ordinary_source_digest_matches': source_digest_matches,
    'python': platform.python_version(),
    'node': subprocess.check_output(['node', '--version'], text=True).strip(),
    'wrapper_sha256': sha(Path(__file__).read_bytes()),
    'commands': records,
    'ordinary_result': {key: ordinary[key] for key in ('tests', 'failures', 'errors', 'skipped', 'success')},
    'out_of_scope_head_change': '5519ff7 adds the independently reviewed MUC matcher; the model anchor remains d9eb2e2. Exact listed working bytes bind this run.',
    'not_run': ['Rust build/test', 'existing OS/listener suite', 'server', 'PostgreSQL', 'wire', 'soak', 'fault injection'],
    'success': stable and source_digest_matches and head_before == head_after
               and ordinary['success'] and all(record['exit_code'] == 0 for record in records),
}
(OUTPUT / 'source-envelope.json').write_text(json.dumps(envelope, indent=2) + '\n')
manifest = {path.name: {'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())}
            for path in sorted(OUTPUT.iterdir()) if path.is_file()}
(OUTPUT / 'artifact-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'success': envelope['success'], 'source_sha256': envelope['source_sha256'],
                  'tests': ordinary['tests'], 'output': str(OUTPUT)}))
raise SystemExit(0 if envelope['success'] else 1)
