"""Record authorized source-only formatting, syntax, and compilation checks.

This does not import project Python modules or execute tests, replay, services,
SQL, or fault scenarios. Run only after the source writer has frozen its files.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/6c1169b97236/northstar-repair')
BASE = '87ec1c238adc87f9e8342c8f7803a67aab271744'
SOURCES = [
    'catalog/runtime-experiments.json',
    'catalog/runtime-experiments.schema.json',
    'crates/northstar-abuse-policy/src/admission_execution.rs',
    'crates/northstar-abuse-policy/src/admission_transaction.rs',
    'crates/northstar-test-harness/src/controlled_admission/execution.rs',
    'crates/northstar-test-harness/src/controlled_admission/input.rs',
    'crates/northstar-test-harness/src/controlled_admission/mod.rs',
    'scripts/lib/controlled_admission.py',
    'scripts/test-controlled-admission.py',
    'src/db/message_admission_repository.rs',
    'src/services/message_admission.rs',
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def save_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def snapshot():
    paths = git('ls-files', '-z').decode().split('\0')
    return {p: sha((ROOT / p).read_bytes()) for p in sorted(paths) if p}


def main():
    assert len(sys.argv) == 2
    destination = Path(sys.argv[1]).resolve()
    assert destination.parent == Path(__file__).resolve().parent
    assert git('rev-parse', 'HEAD').decode().strip() == BASE
    assert not git('diff', '--cached', '--name-only').strip()
    changed = git('diff', '--name-only').decode().splitlines()
    assert set(changed) == set(SOURCES), changed
    assert not git('ls-files', '--others', '--exclude-standard').strip()
    destination.mkdir(exist_ok=False)
    driver = Path(__file__).read_bytes()
    (destination / 'record-ordinary.py').write_bytes(driver)
    before = snapshot()
    save_json(destination / 'source-before.json', before)
    patch = git('diff', '--binary', '--', *SOURCES)
    (destination / 'source.patch').write_bytes(patch)
    env = dict(os.environ)
    env.update({
        'PATH': '/workspace/scratch/6c1169b97236/tools/cargo/bin:' + env.get('PATH', ''),
        'CARGO_HOME': '/workspace/scratch/6c1169b97236/tools/cargo',
        'RUSTUP_HOME': '/workspace/scratch/6c1169b97236/tools/rustup',
        'CARGO_BUILD_JOBS': '1',
        'CARGO_PROFILE_TEST_DEBUG': '0',
        'CARGO_PROFILE_DEV_DEBUG': '0',
        'CARGO_INCREMENTAL': '0',
    })
    json_code = '''import json,pathlib,sys
def pairs(values):
 d={}
 for k,v in values:
  if k in d: raise ValueError("duplicate JSON key: "+k)
  d[k]=v
 return d
for p in sys.argv[1:]: json.loads(pathlib.Path(p).read_text(),object_pairs_hook=pairs)
'''
    commands = [
        ['rustfmt', '--edition', '2021', '--config', 'skip_children=true', '--check',
         *[p for p in SOURCES if p.endswith('.rs')]],
        ['python3', '-B', '-c',
         'import ast,pathlib,sys; [ast.parse(pathlib.Path(p).read_text(),filename=p) for p in sys.argv[1:]]',
         *[p for p in SOURCES if p.endswith('.py')]],
        ['python3', '-B', '-c', json_code,
         *[p for p in SOURCES if p.endswith('.json')]],
        ['cargo', 'check', '--locked', '--offline', '-p', 'northstar-abuse-policy',
         '-p', 'northstar-test-harness', '-p', 'rust-xmpp-server', '--all-targets'],
    ]
    results = []
    for index, command in enumerate(commands, 1):
        log = destination / f'command-{index}.log'
        started = time.monotonic()
        with log.open('wb') as output:
            completed = subprocess.run(command, cwd=ROOT, env=env, stdout=output,
                                       stderr=subprocess.STDOUT, check=False)
        results.append({'command': command, 'exit_code': completed.returncode,
                        'elapsed_seconds': round(time.monotonic() - started, 3),
                        'log': log.name, 'log_sha256': sha(log.read_bytes())})
        print(json.dumps(results[-1]), flush=True)
        if completed.returncode:
            break
    after = snapshot()
    save_json(destination / 'source-after.json', after)
    result = {
        'base_commit': BASE,
        'end_head': git('rev-parse', 'HEAD').decode().strip(),
        'source_patch_sha256': sha(patch),
        'tracked_source_file_count': len(before),
        'source_unchanged': before == after,
        'changed_during_command': [p for p in before.keys() | after.keys()
                                   if before.get(p) != after.get(p)],
        'before_map_sha256': sha((destination / 'source-before.json').read_bytes()),
        'after_map_sha256': sha((destination / 'source-after.json').read_bytes()),
        'driver_sha256': sha(driver),
        'commands': results,
        'scope': 'Ordinary Rust formatting, Python AST/strict JSON syntax and default-feature normal/test target compilation only. No project Python imports, tests, oracle, runner, corpus, replay/shrinking, SQL, services or fault execution.',
    }
    save_json(destination / 'result.json', result)
    print(json.dumps({'result': str(destination / 'result.json'),
                      'source_unchanged': result['source_unchanged']}), flush=True)
    return 0 if before == after and len(results) == len(commands) and all(
        item['exit_code'] == 0 for item in results) else 1


if __name__ == '__main__':
    raise SystemExit(main())
